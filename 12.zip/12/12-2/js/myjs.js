window.onload=function(){
	var frmValue=window.location.search;
	var fileValue=document.getElementById("myfile").value;
	//console.log("文件路径："+fileValue+"\n");
	var index1=fileValue.lastIndexOf(".");
	//console.log(index1);
	var fileExt=fileValue.substring(index1+1);
	//console.log("文件扩展名："+fileExt);
	var index2=fileValue.lastIndexOf("\\");
	//console.log(index2);
	var fileName=fileValue.substring(index2+1,index1);
	//console.log("文件名："+fileName);
	frmValue=decodeURIComponent(frmValue);
	//document.write(frmValue);
	frmValue=frmValue.substring(1);
	//document.write(frmValue+"</br>");
	var urlValue=frmValue.split("&");
	console.log(urlValue);
	for(var i=0;i<urlValue.length;i++){
		var name=urlValue[i].split("=")[0];
		var value=urlValue[i].split("=")[1];
		document.write(name+":"+value+"\n");
	}
	document.write("filename:"+fileName+"\n");
	document.write("fileExt:"+fileExt+"\n");
}
