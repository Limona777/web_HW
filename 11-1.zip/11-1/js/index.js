var selall="<input type=checkbox id=sall onclick=selectAll()>全选";
var selme="<input type=checkbox name=sme onclick=selectMe()>选中";
var action="操作"
var allstr="<a href=# onclick=delrow(this)>删除</a>|<a href=# onclick=editrow(this)>编辑</a>";
var title = new Array(selall, "电影类型", "电影名称", "价格", "操作");
var movie = new Array();
movie[0] = new Array(selme, "动作片", "导火线", "50", allstr);
movie[1] = new Array(selme, "科幻片", "2012", "70", allstr);
movie[2] = new Array(selme, "战争片", "我是战士", "60", allstr);
var oldvalue;
document.write("<table id=mytable border=1 align='center' rules=all>");
document.write("<caption>电影</caption>");
document.write("<tr>");
for(var i = 0; i < title.length; i++) {
	document.write("<th>" + title[i] + "</th>");
}
document.write("</tr>");
for(var r = 0; r < movie.length; r++) {
	document.write("<tr>");
	for(var c = 0; c < title.length; c++) {
		document.write("<td>" + movie[r][c] + "</td>");
	}
	document.write("</tr>");
}
document.write("</table>");
function selectAll(){
	var selall=document.getElementById("sall");
	var selme=document.getElementsByName("sme");
	if(selall.checked)
	 for(var i=0;i<selme.length;i++){
	 	selme[i].checked=true;
	 }
	else
	 for(var i=0;i<selme.length;i++){
	 	selme[i].checked=false;
	 }
}
function selectMe(){
	var selall=document.getElementById("sall");
	var selme=document.getElementsByName("sme");
	var flag;
	for(var j=0;j<selme.length;j++){
		if(!selme[j].checked){
			flag=false;
			break;
		}
		else
		 flag=true;
	}
	selall.checked=flag;
}
function delrow(that){
	var curRow=that.parentNode.parentNode.rowIndex;
	var OjbTable=document.getElementById("mytable");
	if(confirm("确认删除？"))
	  OjbTable.deleteRow(curRow);
}
function editrow(that){
	var tdstr="<a href=# onclick=save(this)>保存</a>|";
	tdstr=tdstr+"<a href=# onclick=cancel(this)>取消</a>";

	var OjbTable=document.getElementById("mytable");
	var curRowIndex=that.parentNode.parentNode.rowIndex;
	var OjbTr=OjbTable.rows[curRowIndex];
	var myTd8=OjbTr.cells.item(4);
	myTd8.innerHTML=tdstr;
	var td5=OjbTr.cells.item(3);
	oldvalue=td5.innerHTML;
	var mystr="<input type=text id=price value="+oldvalue+">";
	td5.innerHTML=mystr;
}
function cancel(that){
	var OjbTable=document.getElementById("mytable");
  var curRowIndex=that.parentNode.parentNode.rowIndex;
  var OjbTr=OjbTable.rows[curRowIndex];
  OjbTr.cells.item(4).innerHTML=allstr;
  OjbTr.cells.item(3).innerHTML=oldvalue;
}
function save(that){
	var OjbTable=document.getElementById("mytable");
  var curRowIndex=that.parentNode.parentNode.rowIndex;
  var OjbTr=OjbTable.rows[curRowIndex];
  var newPrice=document.getElementById("price").value;
  OjbTr.cells.item(4).innerHTML=allstr;
  OjbTr.cells.item(3).innerHTML=newPrice;
}
