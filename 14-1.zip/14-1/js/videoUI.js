window.onload=funtion(){
	var video=document.getElementById("myvideo");
	var play=document.getElementById("play");
	var progress=document.getElementById("progress");
	var bar=document.getElementById("bar");
	var control=document.getElementById("control");
	var sound=document.getElementById("sound");
	var full=document.getElementById("full");
	
	play.onclick=function(){
		if(video.paused){
			video.play();
			play.className="pause";
		}else{
			video.pause();
			play.className="play";
		}
	}
	video.addEventListener("timeupdate",function () {
		var scales=video.currentTime/video.duration;
		bar.style.width=progress.offsetWidth*scales+"px";
		control.style.left=progress.offsetWidth*scales+"px";
		},false);
	control.οnmοusedοwn=function (e) {
		video.pause();
		document.οnmοusemοve=function (e) {
			var leftv=e.clientX-progress.offsetLeft-box.offsetLeft;
			if(leftv<=0){
				leftv=0;
			}
			if(leftv>=progress.offsetWidth){
				leftv=progress.offsetWidth;
			}
			control.style.left=leftv+"px"
			}
		document.οnmοuseup=function () {
			var scales=control.offsetLeft/progress.offsetWidth;
			video.currentTime =video.duration*scales;
			video.play();
			document.οnmοusemοve=null;
			document.οnmοusedοwn=null;
	}
	}
	sound.οnclick=function () {
		if(video.muted){
		video.muted=false;
		sound.className="soundon"
		}else{
		video.muted=true;
		sound.className="soundoff"
		}
	}
}

