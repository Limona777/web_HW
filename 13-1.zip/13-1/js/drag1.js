document.addEventListener("DOMContentLoaded", function() {
  const items = document.querySelectorAll('.item');
  const customers = [document.getElementById('customerA'), 
                     document.getElementById('customerB'),
                     document.getElementById('customerC')];
  
  items.forEach(item => {
    item.addEventListener('dragstart', dragStart);
    item.addEventListener('dragend', dragEnd);
  }

  customers.forEach(customer => {
    customer.addEventListener('dragover', dragOver);
    customer.addEventListener('drop', drop);
  }

  document.getElementById('trash').addEventListener('dragover', dragOver);
  document.getElementById('trash').addEventListener('drop', trash);

  function dragStart(e) {
    e.dataTransfer.setData('text/plain', e.target.id);
  }

  function dragEnd(e) {
    this.style.opacity = '1';
  }

  function dragOver(e) {
    e.preventDefault();
  }

  function drop(e) {
    e.preventDefault();
    const data = e.dataTransfer.getData('text/plain');
    const item = document.getElementById(data);
    if (e.target.classList.contains('customer')) {
      e.target.appendChild(item.cloneNode(true));
    }
  }

  function trash(e) {
    e.preventDefault();
    const data = e.dataTransfer.getData('text/plain');
    const item = document.getElementById(data);
    item.remove();
  }
}