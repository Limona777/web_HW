function reg(){
	var username=document.getElementById("username").value;
	var pwd=document.getElementById("password").value;
	var repwd=document.getElementById("repassword").value;
	if(username==""){
		alert("用户名不能为空");
		return false;
	}
	if(pwd==""){
		alert("密码不能为空");
		return false;
	}
	if(repwd!=pwd){
		alert("两次密码不一致");
		return false;
	}
	else{
		localStorage.setItem("uname",username);
		localStorage.setItem("pwd",pwd);
		alert("注册成功");
	}
	window.location.href="login.html";
}
