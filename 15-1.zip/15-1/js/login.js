function log(){
	var username=document.getElementById("username").value;
	var pwd=document.getElementById("password").value;
	if(username==""||pwd==""){
		alert("不能为空");
		return false;
	}
	if(localStorage.getItem("uname")){
		var uname=localStorage.getItem("uname").toString();
		var pass=localStorage.getItem("pwd").toString();
		if(username==uname){
			if(pwd==pass){
				sessionStorage.setItem("username",uname);
				alert("登陆成功");
				window.location.href="index.html"
			}
			else{
				alert("密码有误");
			}
		}
		else{
			alert("用户名有误");
		}
	}
	else{
		alert("请先注册");
	}
}
function chk(){
	if(sessionStorage.getItem("username")){
		alert("欢迎访问， "+sessionStorage.getItem("username").toString());
	}
	else{
		alert("请先登录");
		window.location.href="login.html";
	}
}
